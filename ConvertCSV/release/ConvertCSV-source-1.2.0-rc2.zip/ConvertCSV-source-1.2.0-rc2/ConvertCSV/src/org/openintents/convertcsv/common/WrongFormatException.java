package org.openintents.convertcsv.common;

public class WrongFormatException extends Exception {

}
